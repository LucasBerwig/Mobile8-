package com.example.appjokenpo;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.Random;

public class MainActivity extends AppCompatActivity {

    int pontuacaoJogador = 0;
    int pontuacaoApp = 0;
    Button btnReiniciar;
    TextView txtReinicio, txtReinicio2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btnReiniciar = findViewById(R.id.btnReiniciar);
        txtReinicio = findViewById(R.id.txtResultado1);
        txtReinicio2 = findViewById(R.id.txtResultado2);

        btnReiniciar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                reiniciarJogo();
            }
        });
    }

    public void selecionadoPedra(View view) {
        opcaoSelecionado("pedra");
    }

    public void selecionadoPapel(View view) {
        opcaoSelecionado("papel");
    }

    public void selecionadoTesoura(View view) {
        opcaoSelecionado("tesoura");
    }

    public void opcaoSelecionado(String opcaoSelecionada) {
        ImageView imageResultado = findViewById(R.id.imgApp);
        TextView txtResult = findViewById(R.id.txtResultado1);
        String[] opcoes = {"pedra", "papel", "tesoura"};
        String opcaoApp = opcoes[new Random().nextInt(3)];

        switch (opcaoApp) {
            case "pedra":
                imageResultado.setImageResource(R.drawable.pedra);
                break;
            case "papel":
                imageResultado.setImageResource(R.drawable.papel);
                break;
            case "tesoura":
                imageResultado.setImageResource(R.drawable.tesoura);
                break;
        }

        if ((opcaoApp.equals("scissor") && opcaoSelecionada.equals("paper")) ||
                (opcaoApp.equals("paper") && opcaoSelecionada.equals("pedra")) ||
                (opcaoApp.equals("pedra") && opcaoSelecionada.equals("scissor"))) {
            txtResult.setText("Resultado: Você PERDEU... :(");
            pontuacaoApp++;
        } else if ((opcaoSelecionada.equals("scissor") && opcaoApp.equals("paper")) ||
                (opcaoSelecionada.equals("paper") && opcaoApp.equals("pedra")) ||
                (opcaoSelecionada.equals("pedra") && opcaoApp.equals("scissor"))) {
            txtResult.setText("Resultado: Você GANHOU... ;D");
            pontuacaoJogador++;
        } else {
            txtResult.setText("Resultado: Vocês EMPATARAM... :|");
        }
        atualizarPlacar();
    }

    public void atualizarPlacar() {
        TextView txtPlacar = findViewById(R.id.txtResultado2);
        txtPlacar.setText("Jogador: " + pontuacaoJogador + " - App: " + pontuacaoApp);
    }

    public void reiniciarJogo() {
        pontuacaoJogador = 0;
        pontuacaoApp = 0;
        atualizarPlacar();
        ImageView imageResultado = findViewById(R.id.imgApp);
        imageResultado.setImageResource(android.R.color.transparent);
        txtReinicio.setText("O jogo foi reiniciado");
        txtReinicio2.setText("...");
    }
}

